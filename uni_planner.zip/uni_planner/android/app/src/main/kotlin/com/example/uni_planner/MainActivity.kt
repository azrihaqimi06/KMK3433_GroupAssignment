package com.example.uni_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
