import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/task_model.dart';

class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({super.key});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _collabController = TextEditingController(); // Controller for team emails

  DateTime _selectedDate = DateTime.now();
  TaskPriority _selectedPriority = TaskPriority.medium;
  final List<String> _teamMembers = []; // List tracking added peers locally

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _collabController.dispose();
    super.dispose();
  }

  void _addTeamMember() {
    final email = _collabController.text.trim();
    if (email.isNotEmpty && email.contains('@')) {
      setState(() {
        _teamMembers.add(email);
        _collabController.clear();
      });
    }
  }

  void _submitData() {
    if (!_formKey.currentState!.validate()) return;

    final newTask = TaskModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: _titleController.text.trim(),
      description: _descController.text.trim(),
      dueDate: _selectedDate,
      priority: _selectedPriority,
      sharedWith: List.from(_teamMembers), // Pass group collaborators list
    );

    if (!context.mounted) return;
    Navigator.pop(context, newTask);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Assignment / Task'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Task Name / Title',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.assignment),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) return 'Please enter a task name';
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _descController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Details / Description',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.description),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) return 'Please enter descriptions';
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Team Collaboration Row Input
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _collabController,
                        decoration: const InputDecoration(
                          labelText: 'Invite Team Member (Email)',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.person_add),
                        ),
                        keyboardType: TextInputType.emailAddress,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: _addTeamMember,
                      icon: const Icon(Icons.add),
                      style: IconButton.styleFrom(backgroundColor: Colors.blue.shade700),
                    ),
                  ],
                ),

                // Displays added team tags dynamically
                if (_teamMembers.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8.0,
                    children: _teamMembers.map((email) {
                      return Chip(
                        label: Text(email, style: const TextStyle(fontSize: 12)),
                        onDeleted: () {
                          setState(() {
                            _teamMembers.remove(email);
                          });
                        },
                        deleteIcon: const Icon(Icons.cancel, size: 16),
                        backgroundColor: Colors.blue.shade50,
                      );
                    }).toList(),
                  ),
                ],
                const SizedBox(height: 16),

                Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.grey.shade400),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: ListTile(
                    leading: const Icon(Icons.calendar_today, color: Colors.blue),
                    title: const Text('Due Date'),
                    trailing: Text(
                      DateFormat('dd MMM yyyy').format(_selectedDate),
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime.now().subtract(const Duration(days: 365)),
                        lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
                      );
                      if (picked != null) setState(() => _selectedDate = picked);
                    },
                  ),
                ),
                const SizedBox(height: 16),

                DropdownButtonFormField<TaskPriority>(
                  value: _selectedPriority,
                  decoration: const InputDecoration(
                    labelText: 'Task Priority Level',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.bar_chart),
                  ),
                  items: TaskPriority.values.map((priority) {
                    String label = priority == TaskPriority.high ? 'High Priority' : priority == TaskPriority.medium ? 'Medium Priority' : 'Low Priority';
                    return DropdownMenuItem(value: priority, child: Text(label));
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _selectedPriority = value);
                  },
                ),
                const SizedBox(height: 32),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _submitData,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('Save Task to Planner', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}