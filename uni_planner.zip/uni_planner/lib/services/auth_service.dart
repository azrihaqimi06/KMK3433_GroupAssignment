import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/user_model.dart';

// An explicit StateNotifier to safely manage our login status across screens
class AuthNotifier extends StateNotifier<UserModel?> {
  AuthNotifier() : super(null); // Initially, no user is logged in (null)

  // Our simulated local database list of registered students
  final List<UserModel> _registeredUsers = [
    UserModel(email: 'student@unimas.my', password: 'password123'), // Default test account
  ];

  // Business logic for registering a new account
  Future<String?> registerUser(String email, String password) async {
    await Future.delayed(const Duration(seconds: 1)); // Network delay simulation

    // Check if user already exists
    final exists = _registeredUsers.any((user) => user.email == email);
    if (exists) {
      return 'This email is already registered!';
    }

    // Save to local database
    final newUser = UserModel(email: email, password: password);
    _registeredUsers.add(newUser);
    state = newUser; // Automatically log them in after registration
    return null; // Return null means success!
  }

  // Business logic for logging in
  Future<String?> loginUser(String email, String password) async {
    await Future.delayed(const Duration(seconds: 1)); // Network delay simulation

    try {
      // Find user with matching credentials
      final user = _registeredUsers.firstWhere(
            (u) => u.email == email && u.password == password,
      );
      state = user; // Log them in successfully
      return null;
    } catch (e) {
      // If no match is found, an exception is thrown
      return 'Invalid email or incorrect password. Please try again!';
    }
  }

  // Business logic for logging out
  void logout() {
    state = null; // Clear active session state
  }
}

// The global Riverpod provider accessed by our UI views
final authProvider = StateNotifierProvider<AuthNotifier, UserModel?>((ref) {
  return AuthNotifier();
});