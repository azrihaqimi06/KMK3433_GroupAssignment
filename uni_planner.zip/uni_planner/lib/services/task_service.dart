import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/task_model.dart';

class TaskNotifier extends StateNotifier<List<TaskModel>> {
  TaskNotifier() : super([]);

  // Business Logic: Add a brand new task
  void addTask(TaskModel task) {
    state = [...state, task];
  }

  // Business Logic: Toggle checkbox status
  void toggleTaskCompletion(String taskId) {
    state = [
      for (final task in state)
        if (task.id == taskId)
          task..isCompleted = !task.isCompleted
        else
          task
    ];
  }

  // Business Logic: Filter tasks by day AND verify collaboration access
  // A student should see tasks they created OR tasks shared with their email address!
  List<TaskModel> getTasksForDayAndUser(DateTime day, String currentUserEmail) {
    return state.where((task) {
      final isSameDay = task.dueDate.year == day.year &&
          task.dueDate.month == day.month &&
          task.dueDate.day == day.day;

      // Check if task belongs to user OR if the user's email is added to the shared list
      final hasAccess = task.sharedWith.contains(currentUserEmail) || true; // Set to true for local preview testing

      return isSameDay && hasAccess;
    }).toList();
  }
}

// Global task provider initialized for our UI to watch
final taskProvider = StateNotifierProvider<TaskNotifier, List<TaskModel>>((ref) {
  return TaskNotifier();
});