import 'package:flutter/material.dart';

enum TaskPriority { low, medium, high }

class TaskModel {
  String id;
  String title;
  String description;
  DateTime dueDate;
  TaskPriority priority;
  bool isCompleted;
  List<String> sharedWith; // For future team collaboration

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.dueDate,
    required this.priority,
    this.isCompleted = false,
    this.sharedWith = const [],
  });

  // Helper method to convert priority enum to displayable text
  String get priorityString {
    switch (priority) {
      case TaskPriority.high:
        return 'High';
      case TaskPriority.medium:
        return 'Medium';
      case TaskPriority.low:
        return 'Low';
    }
  }

  // Helper method to get priority color badge
  Color get priorityColor {
    switch (priority) {
      case TaskPriority.high:
        return Colors.red;
      case TaskPriority.medium:
        return Colors.orange;
      case TaskPriority.low:
        return Colors.green;
    }
  }
}